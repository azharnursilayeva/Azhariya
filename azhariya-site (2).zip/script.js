/* Azhariya — сайт на трёх языках (русский, қазақша, English):
   каталог, меню, «Поделиться», вход и редактор администратора. */

// Пароль администратора (6 цифр). ВНИМАНИЕ: он виден всем, кто откроет код страницы.
// Это не настоящая защита. Для реальной админки нужна проверка на сервере.
var ADMIN_PIN = '650925';
var STORAGE_KEY = 'azhariya_site_v3';
var OLD_KEY = 'azhariya_site_v2';
var LANG_KEY = 'azhariya_lang';
var MAX_PRODUCTS = 24;

var LANGS = ['ru', 'kk', 'en'];
var LANG_NAMES = { ru: 'Русский', kk: 'Қазақша', en: 'English' };
var CATS = ['dresses', 'tops', 'bottoms', 'outer'];
var TONES = ['', 'tone2', 'tone3'];

/* ---------- Переводы интерфейса ---------- */
var I18N = {
  ru: {
    title_suffix: 'женская одежда',
    meta_desc: 'женская одежда, которая подчёркивает твою индивидуальность.',
    eyebrow_prefix: 'Женская одежда',
    nav_home: 'Главная', nav_coll: 'Коллекция', nav_about: 'О бренде', nav_contact: 'Контакты',
    contact_btn: 'Связаться',
    aria_home: 'На главную', aria_nav: 'Основная навигация', aria_mnav: 'Мобильная навигация',
    aria_footnav: 'Навигация в подвале', aria_cart: 'Корзина (демо)', aria_share: 'Поделиться сайтом',
    aria_menu: 'Меню', aria_close: 'Закрыть', aria_cats: 'Категории', aria_lang: 'Язык сайта',
    hero_btn: 'Смотреть коллекцию',
    hero_ph: 'Фото · модель в образе на городской улице, естественный свет',
    hero_ph_aria: 'Место для фотографии: модель в современном образе на городской улице',
    story_ph: 'Фото · портрет, модель в образе, нейтральный городской фон',
    story_ph_aria: 'Место для фотографии: fashion-портрет модели',
    about_eyebrow: 'О бренде',
    f_brand: 'Бренд', f_city: 'Город', f_address: 'Адрес магазина', f_phone: 'Телефон',
    btn_write: 'Написать нам', btn_share: 'Поделиться',
    note: 'Товары, названия и цены — примерные данные для демонстрации. Замените их реальным ассортиментом бренда.',
    adm_open_login: 'Вход для администратора', adm_open_editor: 'Редактор сайта',
    adm_login_title: 'Вход для администратора', adm_pin_label: 'Пароль — 6 цифр', adm_signin: 'Войти',
    adm_hint_login: 'Пароль проверяется только в браузере и не защищает данные. Для реальной админки нужна проверка на сервере.',
    err_len: 'Введите ровно 6 цифр', err_wrong: 'Неверный пароль',
    ed_title: 'Редактор сайта',
    ed_hint: 'Изменения применяются сразу и сохраняются только в этом браузере: другие посетители их не увидят.',
    editing_lang: 'Язык редактируемых текстов',
    ed_reset: 'Сбросить к исходным', ed_reset_confirm: 'Нажмите ещё раз для сброса',
    ed_reset_msg: 'Все тексты и товары вернутся к исходным. Фото будут удалены.',
    ed_reset_done: 'Сайт возвращён к исходным данным.', ed_close: 'Закрыть', ed_logout: 'Выйти',
    shr_title: 'Поделиться сайтом', shr_url_label: 'Ссылка на сайт', shr_copy: 'Скопировать',
    shr_copied: 'Ссылка скопирована.', shr_select: 'Ссылка выделена. Нажмите Ctrl+C (на телефоне: «Копировать»).',
    vk: 'ВКонтакте',
    more: 'Подробнее',
    empty_cat: 'В этой категории пока нет товаров.',
    empty_all: 'Каталог пуст. Войдите как администратор и добавьте первый товар.',
    photo_ph: 'Фото · ', photo_ph_aria: 'Место для фотографии: ', photo_alt: 'Фото: ',
    cat_all: 'Все', cat_dresses: 'Платья', cat_tops: 'Топы', cat_bottoms: 'Низ', cat_outer: 'Верхняя одежда',
    g_brand: 'Бренд и контакты', g_texts: 'Тексты сайта', g_catalog: 'Каталог',
    l_brand: 'Название бренда', l_city: 'Город', l_address: 'Адрес магазина', l_phone: 'Телефон',
    l_ig: 'Instagram (как показать)', l_igurl: 'Ссылка на Instagram (https://…)',
    l_ht: 'Заголовок главной', l_hs: 'Подзаголовок главной', l_ct: 'Заголовок коллекции',
    l_cs: 'Подзаголовок коллекции', l_at: 'Заголовок «О бренде»', l_ax: 'Текст «О бренде»', l_call: 'Призыв',
    product: 'Товар', p_name: 'Название', p_price: 'Цена', p_cat: 'Категория', p_photo: 'Фото',
    remove_photo: 'Убрать фото', up: 'Выше', down: 'Ниже',
    del: 'Удалить товар', del_confirm: 'Нажмите ещё раз, чтобы удалить',
    add: 'Добавить товар', add_limit: 'Достигнут предел каталога', count_of: 'из',
    uploading: 'Загружаю фото…', photo_saved: 'Фото сохранено.', photo_removed: 'Фото убрано.',
    photo_err_type: 'Выберите файл изображения.', photo_err_read: 'Не удалось прочитать файл.',
    photo_err_open: 'Не удалось открыть изображение.',
    photo_err_size: 'Фото слишком большое для памяти браузера. Попробуйте файл меньше.',
    deleted: 'Товар удалён.', added: 'Товар добавлен. Измените название, цену и фото.',
    save_err: 'Не удалось сохранить: память браузера недоступна.', new_name: 'Новый товар'
  },
  kk: {
    title_suffix: 'әйелдер киімі',
    meta_desc: 'жеке болмысыңды айшықтайтын әйелдер киімі.',
    eyebrow_prefix: 'Әйелдер киімі',
    nav_home: 'Басты бет', nav_coll: 'Топтама', nav_about: 'Бренд туралы', nav_contact: 'Байланыс',
    contact_btn: 'Байланысу',
    aria_home: 'Басты бетке', aria_nav: 'Негізгі навигация', aria_mnav: 'Мобильді навигация',
    aria_footnav: 'Төменгі навигация', aria_cart: 'Себет (демо)', aria_share: 'Сайтпен бөлісу',
    aria_menu: 'Мәзір', aria_close: 'Жабу', aria_cats: 'Санаттар', aria_lang: 'Сайт тілі',
    hero_btn: 'Топтаманы қарау',
    hero_ph: 'Фото · қала көшесіндегі модель, табиғи жарық',
    hero_ph_aria: 'Фотосурет орны: қала көшесіндегі заманауи бейнедегі модель',
    story_ph: 'Фото · модель портреті, бейтарап қалалық фон',
    story_ph_aria: 'Фотосурет орны: модельдің сәндік портреті',
    about_eyebrow: 'Бренд туралы',
    f_brand: 'Бренд', f_city: 'Қала', f_address: 'Дүкен мекенжайы', f_phone: 'Телефон',
    btn_write: 'Бізге жазыңыз', btn_share: 'Бөлісу',
    note: 'Тауарлар, атаулар мен бағалар — көрнекілік үшін берілген үлгі деректер. Оларды бренд ассортиментіне ауыстырыңыз.',
    adm_open_login: 'Әкімші кіруі', adm_open_editor: 'Сайт редакторы',
    adm_login_title: 'Әкімші кіруі', adm_pin_label: 'Құпиясөз — 6 сан', adm_signin: 'Кіру',
    adm_hint_login: 'Құпиясөз тек браузерде тексеріледі және деректерді қорғамайды. Нақты әкімші панелі үшін серверде тексеру қажет.',
    err_len: 'Дәл 6 санды енгізіңіз', err_wrong: 'Құпиясөз қате',
    ed_title: 'Сайт редакторы',
    ed_hint: 'Өзгерістер бірден қолданылады және тек осы браузерде сақталады: басқа келушілер оларды көрмейді.',
    editing_lang: 'Мәтіндерді өңдеу тілі',
    ed_reset: 'Бастапқы мәнге қайтару', ed_reset_confirm: 'Қайтару үшін қайта басыңыз',
    ed_reset_msg: 'Барлық мәтіндер мен тауарлар бастапқы күйіне оралады. Фотолар жойылады.',
    ed_reset_done: 'Сайт бастапқы деректерге қайтарылды.', ed_close: 'Жабу', ed_logout: 'Шығу',
    shr_title: 'Сайтпен бөлісу', shr_url_label: 'Сайт сілтемесі', shr_copy: 'Көшіру',
    shr_copied: 'Сілтеме көшірілді.', shr_select: 'Сілтеме белгіленді. Ctrl+C басыңыз (телефонда: «Көшіру»).',
    vk: 'ВКонтакте',
    more: 'Толығырақ',
    empty_cat: 'Бұл санатта әзірге тауар жоқ.',
    empty_all: 'Каталог бос. Әкімші ретінде кіріп, алғашқы тауарды қосыңыз.',
    photo_ph: 'Фото · ', photo_ph_aria: 'Фотосурет орны: ', photo_alt: 'Фото: ',
    cat_all: 'Барлығы', cat_dresses: 'Көйлектер', cat_tops: 'Блузалар', cat_bottoms: 'Төменгі киім', cat_outer: 'Сырт киім',
    g_brand: 'Бренд және байланыс', g_texts: 'Сайт мәтіндері', g_catalog: 'Каталог',
    l_brand: 'Бренд атауы', l_city: 'Қала', l_address: 'Дүкен мекенжайы', l_phone: 'Телефон',
    l_ig: 'Instagram (көрсетілетін мәтін)', l_igurl: 'Instagram сілтемесі (https://…)',
    l_ht: 'Басты беттің тақырыбы', l_hs: 'Басты беттің қосымша жолы', l_ct: 'Топтама тақырыбы',
    l_cs: 'Топтаманың қосымша жолы', l_at: '«Бренд туралы» тақырыбы', l_ax: '«Бренд туралы» мәтіні', l_call: 'Шақыру',
    product: 'Тауар', p_name: 'Атауы', p_price: 'Бағасы', p_cat: 'Санат', p_photo: 'Фото',
    remove_photo: 'Фотоны алып тастау', up: 'Жоғары', down: 'Төмен',
    del: 'Тауарды жою', del_confirm: 'Жою үшін қайта басыңыз',
    add: 'Тауар қосу', add_limit: 'Каталог шегіне жетті', count_of: 'ішінен',
    uploading: 'Фото жүктелуде…', photo_saved: 'Фото сақталды.', photo_removed: 'Фото алынды.',
    photo_err_type: 'Сурет файлын таңдаңыз.', photo_err_read: 'Файлды оқу мүмкін болмады.',
    photo_err_open: 'Суретті ашу мүмкін болмады.',
    photo_err_size: 'Фото браузер жадына сыймайды. Кішірек файл таңдап көріңіз.',
    deleted: 'Тауар жойылды.', added: 'Тауар қосылды. Атауын, бағасын және фотосын өзгертіңіз.',
    save_err: 'Сақтау мүмкін болмады: браузер жады қолжетімсіз.', new_name: 'Жаңа тауар'
  },
  en: {
    title_suffix: "women's clothing",
    meta_desc: "women's clothing that celebrates your individuality.",
    eyebrow_prefix: "Women's clothing",
    nav_home: 'Home', nav_coll: 'Collection', nav_about: 'About', nav_contact: 'Contact',
    contact_btn: 'Get in touch',
    aria_home: 'Go to home', aria_nav: 'Main navigation', aria_mnav: 'Mobile navigation',
    aria_footnav: 'Footer navigation', aria_cart: 'Cart (demo)', aria_share: 'Share the site',
    aria_menu: 'Menu', aria_close: 'Close', aria_cats: 'Categories', aria_lang: 'Site language',
    hero_btn: 'Explore collection',
    hero_ph: 'Photo · model in a look on a city street, natural light',
    hero_ph_aria: 'Photo placeholder: model in a contemporary look on a city street',
    story_ph: 'Photo · portrait, model in a look, neutral city background',
    story_ph_aria: 'Photo placeholder: fashion portrait of a model',
    about_eyebrow: 'About the brand',
    f_brand: 'Brand', f_city: 'City', f_address: 'Store address', f_phone: 'Phone',
    btn_write: 'Contact us', btn_share: 'Share',
    note: "Products, names and prices are sample data for demonstration. Replace them with the brand's real range.",
    adm_open_login: 'Admin login', adm_open_editor: 'Site editor',
    adm_login_title: 'Admin login', adm_pin_label: 'Password — 6 digits', adm_signin: 'Sign in',
    adm_hint_login: 'The password is checked only in the browser and does not protect data. A real admin area needs server-side checks.',
    err_len: 'Enter exactly 6 digits', err_wrong: 'Wrong password',
    ed_title: 'Site editor',
    ed_hint: 'Changes apply immediately and are saved only in this browser: other visitors will not see them.',
    editing_lang: 'Language of the texts being edited',
    ed_reset: 'Reset to defaults', ed_reset_confirm: 'Press again to reset',
    ed_reset_msg: 'All texts and products will return to the defaults. Photos will be removed.',
    ed_reset_done: 'The site has been reset to its default data.', ed_close: 'Close', ed_logout: 'Log out',
    shr_title: 'Share the site', shr_url_label: 'Site link', shr_copy: 'Copy',
    shr_copied: 'Link copied.', shr_select: 'Link selected. Press Ctrl+C (on a phone: “Copy”).',
    vk: 'VK',
    more: 'View product',
    empty_cat: 'There are no products in this category yet.',
    empty_all: 'The catalog is empty. Log in as admin and add the first product.',
    photo_ph: 'Photo · ', photo_ph_aria: 'Photo placeholder: ', photo_alt: 'Photo: ',
    cat_all: 'All', cat_dresses: 'Dresses', cat_tops: 'Tops', cat_bottoms: 'Bottoms', cat_outer: 'Outerwear',
    g_brand: 'Brand and contacts', g_texts: 'Site texts', g_catalog: 'Catalog',
    l_brand: 'Brand name', l_city: 'City', l_address: 'Store address', l_phone: 'Phone',
    l_ig: 'Instagram (display text)', l_igurl: 'Instagram link (https://…)',
    l_ht: 'Home headline', l_hs: 'Home subheading', l_ct: 'Collection headline',
    l_cs: 'Collection subheading', l_at: '“About” headline', l_ax: '“About” text', l_call: 'Call to action',
    product: 'Product', p_name: 'Name', p_price: 'Price', p_cat: 'Category', p_photo: 'Photo',
    remove_photo: 'Remove photo', up: 'Move up', down: 'Move down',
    del: 'Delete product', del_confirm: 'Press again to delete',
    add: 'Add product', add_limit: 'Catalog limit reached', count_of: 'of',
    uploading: 'Uploading photo…', photo_saved: 'Photo saved.', photo_removed: 'Photo removed.',
    photo_err_type: 'Choose an image file.', photo_err_read: 'Could not read the file.',
    photo_err_open: 'Could not open the image.',
    photo_err_size: 'The photo is too large for browser storage. Try a smaller file.',
    deleted: 'Product deleted.', added: 'Product added. Edit its name, price and photo.',
    save_err: 'Could not save: browser storage is unavailable.', new_name: 'New product'
  }
};

/* ---------- Тексты сайта по языкам (их можно править в редакторе) ---------- */
var DEFAULTS = {
  brand: 'Azhariya',
  phone: '[+7 ___ ___ __ __]',
  instagram: '[@instagram]',
  instagramUrl: '',
  t: {
    ru: {
      city: 'Астана, Казахстан', address: 'г. Астана, [улица, дом]',
      heroTitle: 'ТВОЙ СТИЛЬ. ТВОЯ ИСТОРИЯ.',
      heroSub: 'Женская одежда, которая подчёркивает твою индивидуальность',
      collTitle: 'КОЛЛЕКЦИЯ', collSub: 'Повседневная база. Лёгкая элегантность.',
      aboutTitle: 'БОЛЬШЕ, ЧЕМ МОДА',
      aboutText: 'Azhariya — это уверенность, индивидуальность и естественный стиль. Одежда, с которой каждый день становится особенным.',
      callText: 'Найди свой стиль. Сделай его своим.'
    },
    kk: {
      city: 'Астана, Қазақстан', address: 'Астана қ., [көше, үй]',
      heroTitle: 'СЕНІҢ СТИЛІҢ. СЕНІҢ ӘҢГІМЕҢ.',
      heroSub: 'Жеке болмысыңды айшықтайтын әйелдер киімі',
      collTitle: 'ТОПТАМА', collSub: 'Күнделікті базалық киім. Жеңіл талғампаздық.',
      aboutTitle: 'СӘННЕН ДЕ АРТЫҚ',
      aboutText: 'Azhariya — сенімділік, даралық және табиғи стиль. Әр күнді ерекше ететін киім.',
      callText: 'Өз стиліңді тап. Оны өзіңдікі қыл.'
    },
    en: {
      city: 'Astana, Kazakhstan', address: 'Astana, [street, building]',
      heroTitle: 'YOUR STYLE. YOUR STORY.',
      heroSub: "Women's clothing that celebrates your individuality",
      collTitle: 'THE COLLECTION', collSub: 'Everyday essentials. Effortless elegance.',
      aboutTitle: 'MORE THAN FASHION',
      aboutText: 'Azhariya is about confidence, individuality and effortless style. Discover clothing that makes every day feel special.',
      callText: 'Find your style. Make it yours.'
    }
  },
  products: [
    { id: 'p1', name: { ru: 'Повседневный комплект', kk: 'Күнделікті жиынтық', en: 'Everyday Co-ord Set' }, price: 'XX 000 ₸', cat: 'tops', tone: '', img: '' },
    { id: 'p2', name: { ru: 'Платье-комбинация миди', kk: 'Миди көйлек-комбинация', en: 'Midi Slip Dress' }, price: 'XX 000 ₸', cat: 'dresses', tone: 'tone2', img: '' },
    { id: 'p3', name: { ru: 'Классическая рубашка', kk: 'Классикалық жейде', en: 'Classic Poplin Shirt' }, price: 'XX 000 ₸', cat: 'tops', tone: 'tone3', img: '' },
    { id: 'p4', name: { ru: 'Широкие брюки', kk: 'Кең шалбар', en: 'Wide-Leg Trousers' }, price: 'XX 000 ₸', cat: 'bottoms', tone: 'tone2', img: '' },
    { id: 'p5', name: { ru: 'Джинсы прямого кроя', kk: 'Түзу пішімді джинсы', en: 'Straight Denim' }, price: 'XX 000 ₸', cat: 'bottoms', tone: '', img: '' },
    { id: 'p6', name: { ru: 'Приталенное пальто', kk: 'Пішімді пальто', en: 'Tailored Coat' }, price: 'XX 000 ₸', cat: 'outer', tone: 'tone3', img: '' }
  ]
};
var TEXT_KEYS = ['city', 'address', 'heroTitle', 'heroSub', 'collTitle', 'collSub', 'aboutTitle', 'aboutText', 'callText'];
var OLD_CATS = { 'Платья': 'dresses', 'Топы': 'tops', 'Низ': 'bottoms', 'Верхняя одежда': 'outer' };

var lang = loadLang();
var site = load();
var currentCat = 'all';
var isAdmin = false;
var lastFocus = null;
var pendingDelete = null;
var pendingReset = false;
var statusMsg = '';

function clone(o) { return JSON.parse(JSON.stringify(o)); }
function str(v, d) { return typeof v === 'string' ? v : d; }
function newId() { return 'p' + Date.now().toString(36) + Math.floor(Math.random() * 1000).toString(36); }
function t(key) { return (I18N[lang] && I18N[lang][key]) || I18N.ru[key] || key; }
function catLabel(c) { return t('cat_' + c); }

function loadLang() {
  try {
    var s = window.localStorage.getItem(LANG_KEY);
    if (LANGS.indexOf(s) >= 0) return s;
  } catch (e) {}
  var n = String((navigator.language || 'ru')).toLowerCase();
  if (n.indexOf('kk') === 0) return 'kk';
  if (n.indexOf('en') === 0) return 'en';
  return 'ru';
}

/* Загрузка данных (с переносом из прежней версии без языков) */
function load() {
  var s = clone(DEFAULTS);
  var raw = null, migrated = false;
  try {
    raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) { raw = window.localStorage.getItem(OLD_KEY); migrated = !!raw; }
  } catch (e) {}
  if (raw) {
    try {
      var saved = JSON.parse(raw);
      s.brand = str(saved.brand, s.brand);
      s.phone = str(saved.phone, s.phone);
      s.instagram = str(saved.instagram, s.instagram);
      s.instagramUrl = str(saved.instagramUrl, s.instagramUrl);
      if (s.instagram === '[@ваш_аккаунт]') s.instagram = DEFAULTS.instagram;
      if (migrated) {
        TEXT_KEYS.forEach(function (k) { s.t.ru[k] = str(saved[k], s.t.ru[k]); });
      } else if (saved.t) {
        LANGS.forEach(function (l) {
          TEXT_KEYS.forEach(function (k) { s.t[l][k] = str((saved.t[l] || {})[k], s.t[l][k]); });
        });
      }
      if (Array.isArray(saved.products)) {
        s.products = saved.products.slice(0, MAX_PRODUCTS).map(function (p, i) {
          var def = DEFAULTS.products.filter(function (d) { return d.id === p.id; })[0];
          var name = {};
          LANGS.forEach(function (l) {
            if (p.name && typeof p.name === 'object') {
              name[l] = str(p.name[l], def ? def.name[l] : '');
            } else {
              var ruName = str(p.name, '');
              name[l] = (l === 'ru') ? ruName : (def && def.name.ru === ruName ? def.name[l] : ruName);
            }
          });
          var cat = CATS.indexOf(p.cat) >= 0 ? p.cat : (OLD_CATS[p.cat] || CATS[0]);
          return {
            id: str(p.id, newId()), name: name, price: str(p.price, ''), cat: cat,
            tone: TONES.indexOf(p.tone) >= 0 ? p.tone : TONES[i % 3],
            img: /^data:image\//.test(p.img || '') ? p.img : ''
          };
        });
      }
    } catch (e) { /* повреждённые данные — используем значения по умолчанию */ }
  }
  ['ru', 'kk', 'en'].forEach(function (l) {
    ['city', 'address'].forEach(function (k) {
      if (s.t[l][k].indexOf('Уржар') >= 0) s.t[l][k] = DEFAULTS.t[l][k];
    });
  });
  return s;
}

function save() {
  try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(site)); return true; }
  catch (e) { return false; }
}

function tx(key) { return site.t[lang][key]; }
function pname(p) { return p.name[lang] || p.name.ru || ''; }

/* ---------- Подстановка текстов ---------- */
function computed() {
  return {
    eyebrow: t('eyebrow_prefix') + ' · ' + tx('city'),
    copy: '© ' + new Date().getFullYear() + ' ' + site.brand + '. ' + tx('city') + '.'
  };
}

function applyStatic() {
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-i18n]').forEach(function (el) {
    el.textContent = t(el.getAttribute('data-i18n'));
  });
  document.querySelectorAll('[data-i18n-aria]').forEach(function (el) {
    el.setAttribute('aria-label', t(el.getAttribute('data-i18n-aria')));
  });
  document.querySelectorAll('[data-lang]').forEach(function (b) {
    var on = b.getAttribute('data-lang') === lang;
    b.classList.toggle('on', on);
    b.setAttribute('aria-pressed', on ? 'true' : 'false');
  });
  openBtn.textContent = isAdmin ? t('adm_open_editor') : t('adm_open_login');
  resetBtn.textContent = pendingReset ? t('ed_reset_confirm') : t('ed_reset');
}

function applyText() {
  var extra = computed();
  document.querySelectorAll('[data-bind]').forEach(function (el) {
    var key = el.getAttribute('data-bind');
    var v;
    if (key in extra) v = extra[key];
    else if (TEXT_KEYS.indexOf(key) >= 0) v = tx(key);
    else v = site[key];
    v = v == null ? '' : String(v);
    el.textContent = el.hasAttribute('data-upper') ? v.toUpperCase() : v;
  });
  var ig = document.getElementById('ig-link');
  if (ig) {
    var url = (site.instagramUrl || '').trim();
    if (/^https:\/\//i.test(url)) {
      ig.setAttribute('href', url);
      ig.setAttribute('target', '_blank');
      ig.setAttribute('rel', 'noopener');
    } else {
      ig.setAttribute('href', '#contact');
      ig.removeAttribute('target');
      ig.removeAttribute('rel');
    }
  }
  var city = tx('city').split(',')[0];
  document.title = site.brand + ' — ' + t('title_suffix') + ', ' + city;
  var md = document.querySelector('meta[name="description"]');
  if (md) md.setAttribute('content', site.brand + ' — ' + t('meta_desc') + ' ' + tx('city') + '.');
}

/* ---------- Каталог ---------- */
function renderCats() {
  var box = document.getElementById('cats');
  box.innerHTML = '';
  ['all'].concat(CATS).forEach(function (c) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'cat' + (c === currentCat ? ' on' : '');
    b.textContent = catLabel(c);
    b.setAttribute('aria-pressed', c === currentCat ? 'true' : 'false');
    b.addEventListener('click', function () { currentCat = c; renderCats(); renderGrid(); });
    box.appendChild(b);
  });
}

function renderGrid() {
  var grid = document.getElementById('grid');
  grid.innerHTML = '';
  var shown = 0;
  site.products.forEach(function (p) {
    if (currentCat !== 'all' && p.cat !== currentCat) return;
    shown++;
    var nm = pname(p);
    var card = document.createElement('article');
    card.className = 'card';

    var frame = document.createElement('div');
    frame.className = 'frame';
    var ph = document.createElement('div');
    ph.className = 'ph' + (p.tone ? ' ' + p.tone : '');
    if (p.img) {
      var img = document.createElement('img');
      img.src = p.img; img.alt = nm; img.loading = 'lazy';
      ph.appendChild(img);
    } else {
      ph.setAttribute('role', 'img');
      ph.setAttribute('aria-label', t('photo_ph_aria') + nm);
      var sp = document.createElement('span');
      sp.textContent = t('photo_ph') + nm;
      ph.appendChild(sp);
    }
    frame.appendChild(ph);

    var meta = document.createElement('div');
    meta.className = 'card-m';
    var h = document.createElement('h3'); h.className = 'card-n'; h.textContent = nm;
    var pr = document.createElement('p'); pr.className = 'price'; pr.textContent = p.price;
    meta.appendChild(h); meta.appendChild(pr);

    var tag = document.createElement('p');
    tag.className = 'tag';
    tag.textContent = catLabel(p.cat);

    var a = document.createElement('a');
    a.className = 'btn ghost sm';
    a.href = '#contact';
    a.textContent = t('more');

    card.appendChild(frame); card.appendChild(meta); card.appendChild(tag); card.appendChild(a);
    grid.appendChild(card);
  });
  if (!shown) {
    var empty = document.createElement('p');
    empty.className = 'empty';
    empty.textContent = site.products.length ? t('empty_cat') : t('empty_all');
    grid.appendChild(empty);
  }
}

/* ---------- Мобильное меню ---------- */
var burger = document.getElementById('burger');
var mnav = document.getElementById('mnav');
burger.addEventListener('click', function () {
  var open = mnav.classList.toggle('open');
  burger.setAttribute('aria-expanded', open ? 'true' : 'false');
});
mnav.querySelectorAll('a').forEach(function (a) {
  a.addEventListener('click', function () {
    mnav.classList.remove('open');
    burger.setAttribute('aria-expanded', 'false');
  });
});

/* ---------- Администратор ---------- */
var ovl = document.getElementById('adm');
var dlg = document.getElementById('dlg');
var loginBox = document.getElementById('adm-login');
var panelBox = document.getElementById('adm-panel');
var form = document.getElementById('adm-form');
var pinInput = document.getElementById('adm-pin');
var errEl = document.getElementById('adm-err');
var openBtn = document.getElementById('adm-open');
var resetBtn = document.getElementById('adm-reset');
var statusEl = document.getElementById('adm-status');

function setStatus(msg) {
  statusMsg = msg || '';
  if (statusEl) statusEl.textContent = statusMsg;
}

function showAdminView() {
  loginBox.hidden = isAdmin;
  panelBox.hidden = !isAdmin;
  dlg.classList.toggle('wide', isAdmin);
  dlg.setAttribute('aria-labelledby', isAdmin ? 'adm-h2' : 'adm-h');
  applyStatic();
  if (isAdmin) buildFields();
}

function openAdmin() {
  lastFocus = document.activeElement;
  errEl.textContent = '';
  pinInput.value = '';
  pendingDelete = null;
  pendingReset = false;
  setStatus('');
  showAdminView();
  ovl.hidden = false;
  var target = isAdmin ? panelBox.querySelector('input,textarea,select') : pinInput;
  if (target) target.focus();
}

function closeAdmin() {
  ovl.hidden = true;
  if (lastFocus && lastFocus.focus) lastFocus.focus();
}

openBtn.addEventListener('click', openAdmin);
document.getElementById('adm-close').addEventListener('click', closeAdmin);
document.getElementById('adm-close2').addEventListener('click', closeAdmin);
ovl.addEventListener('mousedown', function (e) { if (e.target === ovl) closeAdmin(); });
document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape' && !ovl.hidden) closeAdmin();
});

pinInput.addEventListener('input', function () {
  pinInput.value = pinInput.value.replace(/\D/g, '').slice(0, 6);
  errEl.textContent = '';
});

form.addEventListener('submit', function (e) {
  e.preventDefault();
  var pin = pinInput.value.trim();
  pinInput.value = '';
  if (!/^\d{6}$/.test(pin)) { errEl.textContent = t('err_len'); return; }
  if (pin !== ADMIN_PIN) { errEl.textContent = t('err_wrong'); return; }
  isAdmin = true;
  showAdminView();
  var first = panelBox.querySelector('input,textarea,select');
  if (first) first.focus();
});

document.getElementById('adm-logout').addEventListener('click', function () {
  isAdmin = false;
  showAdminView();
  closeAdmin();
});

/* Сброс: подтверждение внутри страницы (confirm() в просмотре не работает) */
resetBtn.addEventListener('click', function () {
  if (!pendingReset) {
    pendingReset = true;
    resetBtn.textContent = t('ed_reset_confirm');
    setStatus(t('ed_reset_msg'));
    return;
  }
  site = clone(DEFAULTS);
  try { window.localStorage.removeItem(STORAGE_KEY); window.localStorage.removeItem(OLD_KEY); } catch (e) {}
  pendingReset = false;
  pendingDelete = null;
  refresh();
  buildFields();
  resetBtn.textContent = t('ed_reset');
  setStatus(t('ed_reset_done'));
});

/* Сжатие фото перед сохранением, чтобы поместиться в память браузера */
function readPhoto(file, cb) {
  if (!file || !/^image\//.test(file.type)) { cb(null, t('photo_err_type')); return; }
  var fr = new FileReader();
  fr.onerror = function () { cb(null, t('photo_err_read')); };
  fr.onload = function () {
    var im = new Image();
    im.onerror = function () { cb(null, t('photo_err_open')); };
    im.onload = function () {
      var max = 900;
      var k = Math.min(1, max / Math.max(im.width, im.height));
      var c = document.createElement('canvas');
      c.width = Math.round(im.width * k);
      c.height = Math.round(im.height * k);
      var ctx = c.getContext('2d');
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, c.width, c.height);
      ctx.drawImage(im, 0, 0, c.width, c.height);
      cb(c.toDataURL('image/jpeg', 0.8));
    };
    im.src = fr.result;
  };
  fr.readAsDataURL(file);
}

/* Поля редактора */
function buildFields() {
  var box = document.getElementById('fields');
  box.innerHTML = '';

  function head(text, extra) {
    var h = document.createElement('h3'); h.className = 'gh'; h.textContent = text;
    if (extra) h.appendChild(extra);
    box.appendChild(h);
  }
  function field(id, label, value, multi, full, onChange, parent) {
    var wrap = document.createElement('div');
    wrap.className = 'fld' + (full ? ' full' : '');
    var l = document.createElement('label'); l.htmlFor = id; l.textContent = label;
    var inp = document.createElement(multi ? 'textarea' : 'input');
    inp.id = id; inp.className = 'inp';
    if (multi) inp.rows = 3; else inp.type = 'text';
    inp.value = value;
    inp.addEventListener('input', function () { onChange(inp.value); });
    wrap.appendChild(l); wrap.appendChild(inp);
    (parent || box).appendChild(wrap);
  }
  function persist() { if (!save()) setStatus(t('save_err')); }
  function common(key, id, labelKey, full) {
    field(id, t(labelKey), site[key], false, full, function (v) { site[key] = v; persist(); refresh(); });
  }
  function texts(key, id, labelKey, multi, full) {
    field(id, t(labelKey), site.t[lang][key], multi, full, function (v) { site.t[lang][key] = v; persist(); refresh(); });
  }

  head(t('g_brand'));
  common('brand', 'f-brand', 'l_brand', false);
  texts('city', 'f-city', 'l_city', false, false);
  texts('address', 'f-addr', 'l_address', false, true);
  common('phone', 'f-phone', 'l_phone', false);
  common('instagram', 'f-ig', 'l_ig', false);
  common('instagramUrl', 'f-igurl', 'l_igurl', true);
  head(t('g_texts'));
  texts('heroTitle', 'f-ht', 'l_ht', false, true);
  texts('heroSub', 'f-hs', 'l_hs', true, true);
  texts('collTitle', 'f-ct', 'l_ct', false, false);
  texts('collSub', 'f-cs', 'l_cs', false, false);
  texts('aboutTitle', 'f-at', 'l_at', false, true);
  texts('aboutText', 'f-ax', 'l_ax', true, true);
  texts('callText', 'f-call', 'l_call', false, true);

  var count = document.createElement('span');
  count.className = 'count';
  count.textContent = ' · ' + site.products.length + ' ' + t('count_of') + ' ' + MAX_PRODUCTS;
  head(t('g_catalog'), count);

  site.products.forEach(function (p, i) {
    var item = document.createElement('div');
    item.className = 'prod full';
    var title = document.createElement('p');
    title.className = 'prod-t';
    title.textContent = t('product') + ' ' + (i + 1) + ' · ' + LANG_NAMES[lang];
    item.appendChild(title);

    var row = document.createElement('div');
    row.className = 'prod-f';
    field('f-pn' + p.id, t('p_name'), p.name[lang] || '', false, false, function (v) {
      p.name[lang] = v; persist(); renderGrid();
    }, row);
    field('f-pp' + p.id, t('p_price'), p.price, false, false, function (v) {
      p.price = v; persist(); renderGrid();
    }, row);

    var cw = document.createElement('div');
    cw.className = 'fld';
    var cl = document.createElement('label'); cl.htmlFor = 'f-pc' + p.id; cl.textContent = t('p_cat');
    var sel = document.createElement('select');
    sel.id = 'f-pc' + p.id; sel.className = 'inp';
    CATS.forEach(function (c) {
      var o = document.createElement('option'); o.value = c; o.textContent = catLabel(c);
      if (c === p.cat) o.selected = true;
      sel.appendChild(o);
    });
    sel.addEventListener('change', function () { p.cat = sel.value; persist(); renderGrid(); });
    cw.appendChild(cl); cw.appendChild(sel); row.appendChild(cw);

    var pw = document.createElement('div');
    pw.className = 'fld';
    var pl = document.createElement('label'); pl.htmlFor = 'f-pf' + p.id; pl.textContent = t('p_photo');
    var file = document.createElement('input');
    file.type = 'file'; file.accept = 'image/*'; file.id = 'f-pf' + p.id; file.className = 'inp file';
    file.addEventListener('change', function () {
      var f = file.files && file.files[0];
      if (!f) return;
      setStatus(t('uploading'));
      readPhoto(f, function (data, err) {
        if (err) { setStatus(err); return; }
        var old = p.img;
        p.img = data;
        if (!save()) { p.img = old; setStatus(t('photo_err_size')); return; }
        renderGrid();
        buildFields();
        setStatus(t('photo_saved'));
      });
    });
    pw.appendChild(pl); pw.appendChild(file); row.appendChild(pw);
    item.appendChild(row);

    var acts = document.createElement('div');
    acts.className = 'prod-a';
    if (p.img) {
      var thumb = document.createElement('img');
      thumb.className = 'thumb'; thumb.src = p.img; thumb.alt = t('photo_alt') + pname(p);
      acts.appendChild(thumb);
      var rm = document.createElement('button');
      rm.type = 'button'; rm.className = 'btn ghost sm'; rm.textContent = t('remove_photo');
      rm.addEventListener('click', function () {
        p.img = ''; persist(); renderGrid(); buildFields(); setStatus(t('photo_removed'));
      });
      acts.appendChild(rm);
    }
    function mover(label, delta) {
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'btn ghost sm'; b.textContent = label;
      var j = i + delta;
      if (j < 0 || j >= site.products.length) b.disabled = true;
      b.addEventListener('click', function () {
        var tmp = site.products[i]; site.products[i] = site.products[j]; site.products[j] = tmp;
        persist(); renderGrid(); buildFields();
        var again = document.getElementById('f-pn' + p.id);
        if (again) again.focus();
      });
      return b;
    }
    acts.appendChild(mover(t('up'), -1));
    acts.appendChild(mover(t('down'), 1));

    var del = document.createElement('button');
    del.type = 'button';
    del.className = 'btn ghost sm danger';
    del.setAttribute('data-del', p.id);
    del.textContent = pendingDelete === p.id ? t('del_confirm') : t('del');
    del.addEventListener('click', function () {
      if (pendingDelete !== p.id) {
        pendingDelete = p.id;
        buildFields();
        var again = box.querySelector('[data-del="' + p.id + '"]');
        if (again) again.focus();
        return;
      }
      pendingDelete = null;
      site.products = site.products.filter(function (x) { return x.id !== p.id; });
      persist(); renderGrid(); buildFields();
      setStatus(t('deleted'));
    });
    acts.appendChild(del);
    item.appendChild(acts);
    box.appendChild(item);
  });

  var addWrap = document.createElement('div');
  addWrap.className = 'fld full';
  var add = document.createElement('button');
  add.type = 'button';
  add.className = 'btn';
  add.textContent = t('add');
  if (site.products.length >= MAX_PRODUCTS) { add.disabled = true; add.textContent = t('add_limit'); }
  add.addEventListener('click', function () {
    var n = site.products.length;
    var nn = {};
    LANGS.forEach(function (l) { nn[l] = I18N[l].new_name; });
    var p = { id: newId(), name: nn, price: '0 ₸', cat: CATS[0], tone: TONES[n % 3], img: '' };
    site.products.push(p);
    persist(); renderGrid(); buildFields();
    var inp = document.getElementById('f-pn' + p.id);
    if (inp) { inp.focus(); inp.select(); }
    setStatus(t('added'));
  });
  addWrap.appendChild(add);
  box.appendChild(addWrap);

  if (statusEl) statusEl.textContent = statusMsg;
}

/* ---------- Выбор языка ---------- */
function setLang(l) {
  if (LANGS.indexOf(l) < 0 || l === lang) return;
  lang = l;
  try { window.localStorage.setItem(LANG_KEY, l); } catch (e) {}
  pendingDelete = null;
  refresh();
  if (isAdmin && !panelBox.hidden) buildFields();
}
document.querySelectorAll('[data-lang]').forEach(function (b) {
  b.addEventListener('click', function () { setLang(b.getAttribute('data-lang')); });
});

function refresh() {
  applyStatic();
  applyText();
  renderCats();
  renderGrid();
}

/* ---------- Поделиться ---------- */
var shr = document.getElementById('shr');
var shrUrl = document.getElementById('shr-url');
var shrStatus = document.getElementById('shr-status');
var shrLast = null;

function siteUrl() { return window.location.href.split('#')[0]; }
function shareText() { return site.brand + ' — ' + t('title_suffix') + ', ' + tx('city').split(',')[0]; }
function setShareLinks() {
  var u = encodeURIComponent(siteUrl());
  var tt = encodeURIComponent(shareText());
  document.getElementById('sh-tg').href = 'https://t.me/share/url?url=' + u + '&text=' + tt;
  document.getElementById('sh-wa').href = 'https://wa.me/?text=' + tt + '%20' + u;
  document.getElementById('sh-vk').href = 'https://vk.com/share.php?url=' + u + '&title=' + tt;
  document.getElementById('sh-fb').href = 'https://www.facebook.com/sharer/sharer.php?u=' + u;
}
function openShare(btn) {
  shrLast = btn || document.activeElement;
  shrUrl.value = siteUrl();
  shrStatus.textContent = '';
  setShareLinks();
  shr.hidden = false;
  shrUrl.focus();
  shrUrl.select();
}
function closeShare() {
  shr.hidden = true;
  if (shrLast && shrLast.focus) shrLast.focus();
}
document.querySelectorAll('[data-share]').forEach(function (b) {
  b.addEventListener('click', function () {
    var data = { title: shareText(), text: shareText(), url: siteUrl() };
    if (navigator.share && /^https?:/.test(data.url)) {
      navigator.share(data).catch(function (err) {
        if (err && err.name === 'AbortError') return;
        openShare(b);
      });
    } else {
      openShare(b);
    }
  });
});
document.getElementById('shr-close').addEventListener('click', closeShare);
shr.addEventListener('mousedown', function (e) { if (e.target === shr) closeShare(); });
document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape' && !shr.hidden) closeShare();
});
document.getElementById('shr-copy').addEventListener('click', function () {
  function fallback() {
    shrUrl.focus();
    shrUrl.select();
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) {}
    shrStatus.textContent = ok ? t('shr_copied') : t('shr_select');
  }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(shrUrl.value).then(function () {
      shrStatus.textContent = t('shr_copied');
    }, fallback);
  } else {
    fallback();
  }
});

/* ---------- Старт ---------- */
refresh();
